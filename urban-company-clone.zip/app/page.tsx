"use client"

import App from "../App"

export default function SyntheticV0PageForDeployment() {
  return <App />
}